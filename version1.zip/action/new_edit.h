#ifndef NEW_EDIT_H
#define NEW_EDIT_H

#include <QWidget>
#include <QLineEdit>
#include <QFormLayout>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFile>
#include <QDataStream>
#include <QMessageBox>

class new_edit : public QDialog
{
    Q_OBJECT
public:
    new_edit(); // construct
signals:
    void closeEdit(); // 信号，新建信息输入完毕
public slots:
    //void saveDoc(); // 保存新建文档信息
public:
    void ok_closs(); // 关闭本界面
private:
    QLineEdit *title;
    QPushButton *create;
    QPushButton *cancel;
};

#endif // NEW_EDIT_H
