#ifndef LABELCLICK_H
#define LABELCLICK_H

#endif // LABELCLICK_H
#include <QWidget>
#include <QLabel>
#include <QCheckBox>
#include <QGridLayout>
#include <QMouseEvent>

class mylabel;

//继承QLabel
class mylabel:public QLabel
{
    Q_OBJECT
public:
    mylabel(){}
signals:
    void gethover();  //悬停
    void getclicked();
private:
    void mouseReleaseEvent(QMouseEvent * ev)   //鼠标释放事件
    {
         if(ev != nullptr)
            if(ev->button() == Qt::LeftButton)
            {
              emit getclicked();	// 发射信号
            }
    }
    void mouseHoverEvent(QMouseEvent * ev)
    {
        if (ev != nullptr)
            if(ev->buttons() & Qt::LeftButton) //进行的按位与
            {
                emit gethover();
            }
    }

};

class Widget : public QWidget
{
    Q_OBJECT
public:
    Widget(QWidget *parent = 0);
    ~Widget();
private:
    mylabel *label = nullptr ; //使用自己的类
    QGridLayout  * layout = nullptr;
};
