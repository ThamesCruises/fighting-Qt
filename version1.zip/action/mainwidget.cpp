﻿#include "mainWidget.h"
#include <QtDebug>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QTextEdit>
#include <QLabel>
#include <QPushButton>
#include <QMouseEvent>

mainWidget::mainWidget()
{
    setWindowTitle("未名笔记");
    this->resize(1000, 1000);
    QVBoxLayout *VBoxLayout = new QVBoxLayout(this);

    QGroupBox *upBox = createRight();
    QGroupBox *downBox = createShowBox();
    setMouseTracking(true);
    VBoxLayout->addWidget(upBox, 5);
    VBoxLayout->addWidget(downBox, 2);
}

QGroupBox *mainWidget::createRight()
{
    QGroupBox *box = new QGroupBox;
    doc1 = new QLabel; doc2 = new QLabel; doc3 = new QLabel; doc4 = new QLabel;
    doc5 = new QLabel; doc6 = new QLabel; doc7 = new QLabel; doc8 = new QLabel;
    newDoc = new mylabel;
    QGridLayout *Glayout = new QGridLayout;
    QString stylesheet = "border-width: 6px;border-style: solid;border-color:rgb(199,191,230);background-color:rgb(250,250,238);color:rgb(199,191,230);";
    stylesheet.append("font-family:Comic Sans MS;");
    stylesheet.append("font-size:18pt");
    Glayout->setSpacing(10);

    doc1->setFrameStyle(QFrame::Box);
    doc1->setAlignment(Qt::AlignCenter);
    doc1->setStyleSheet(stylesheet);
    doc2->setFrameStyle(QFrame::Box);
    doc2->setStyleSheet(stylesheet);
    doc2->setAlignment(Qt::AlignCenter);
    doc3->setFrameStyle(QFrame::Box);
    doc3->setStyleSheet(stylesheet);
    doc3->setAlignment(Qt::AlignCenter);
    doc4->setFrameStyle(QFrame::Box);
    doc4->setStyleSheet(stylesheet);
    doc4->setAlignment(Qt::AlignCenter);
    newDoc->setAlignment(Qt::AlignCenter);

    newDoc->setStyleSheet("color:#FFFFFF;background-color:rgb(152,215,245);front:260pt;border-radius:30px;border:2px;border-color: rgb(152,215,245);front-weight:bold;");
    QFont ft;
    ft.setPointSize(32);
    newDoc->setFont(ft);
    newDoc->setText("+");
    doc1->setText("tag1");
    doc2->setText("tag2");
    doc3->setText("tag3");
    doc4->setText("tag4");

    Glayout->addWidget(doc1,1,1,4,4);
    Glayout->addWidget(doc2,1,9,4,4);
    Glayout->addWidget(doc3,1,17,4,4);
    Glayout->addWidget(doc4,9,1,4,4);
    Glayout->addWidget(newDoc,24,24,1,1);
    box->setLayout(Glayout);

    connect(newDoc,&mylabel::getclicked,this,&mainWidget::show_newEdit);
    return box;
}

QGroupBox *mainWidget::createShowBox()
{
    QGroupBox *box = new QGroupBox;
    QHBoxLayout *autolayout = new QHBoxLayout;
    QTextEdit *preview = new QTextEdit;
    preview->setCursorWidth(1);
    autolayout->addWidget(preview);
    box->setLayout(autolayout);
    return box;
}

void mainWidget::show_newEdit()
{// 点击新建按钮后，更新主页面显示并清空预览文本框里的内容
    newDocDialogue = new new_edit;
    //QObject::connect(newDocDialogue,&new_edit::closeEdit, this, &mainWidget::renewWidget);
    //QObject::connect(newDocDialogue,&new_edit::closeEdit, preview, &QTextEdit::clear);
    newDocDialogue->exec();
}
