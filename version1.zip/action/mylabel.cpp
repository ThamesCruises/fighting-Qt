#include "mylabel.h"
Widget::~Widget()
{

}
