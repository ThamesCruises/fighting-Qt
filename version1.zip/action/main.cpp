#include "mainWidget.h"
#include <QMouseEvent>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    mainWidget w;
    w.show();

    a.exec();
    return 0;
}
