#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QListWidget>
#include <QTableWidget>
#include <QGroupBox>
#include <QPushButton>
#include <QLineEdit>
#include <QFile>
#include <QDataStream>
#include <QTextEdit>
#include "new_edit.h"
#include "mylabel.h"

class mainWidget : public QWidget
{
    Q_OBJECT
public:
    mainWidget();
    void show_newEdit(); // 显示新建文档界面
public slots:
    //void renewWidget(); // 更新主界面的显示
    //void delDoc(); // 删除文档
    //void findDoc(); // 查找文档
    //void writeinDoc(); // 进入文档开始编辑

private:
    QGroupBox* createRight(); // 就是右半边
    QGroupBox* createShowBox(); // 预览，做不出来备忘录的效果qaq

    QTextEdit* preview;
    mylabel* newDoc; // 新建按钮
    QLineEdit* findDocButton; // 查找的输入栏
    // Doc们
    QLabel* doc1, *doc2, *doc3, *doc4, *doc5, *doc6, *doc7, *doc8;
    QLabel* doc9, *doc10, *doc11, *doc12, *doc13, *doc14, *doc15, *doc16;

    new_edit* newDocDialogue;
};

#endif // MAINWIDGET_H
