#include "new_edit.h"

new_edit::new_edit()
{
    setWindowTitle("new");
    this->resize(500,300);
    QVBoxLayout *Vout = new QVBoxLayout;
    QHBoxLayout *Hout = new QHBoxLayout;
    QHBoxLayout *autolay = new QHBoxLayout;

    title = new QLineEdit;
    create = new QPushButton("create");
    cancel = new QPushButton("cancel");
    title->setPlaceholderText("tag your note");
    title->setClearButtonEnabled(true);
    autolay->addWidget(title);
    Hout->addWidget(cancel);
    Hout->addWidget(create);

    Vout->addLayout(autolay, 1);
    Vout->addLayout(Hout, 1);
    this->setLayout(Vout);

    QObject::connect(cancel,&QPushButton::clicked,this,&new_edit::close);
    QObject::connect(create,&QPushButton::clicked,this,&new_edit::close);
}
